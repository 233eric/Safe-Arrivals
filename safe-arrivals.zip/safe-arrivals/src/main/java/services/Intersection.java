package services;

/**
 * <h1> The Intersection Class </h1>
 * An ADT representing a Intersection 
 */
public class Intersection implements Comparable<Intersection>{
	///Latitude of Intersection
	private double lat;
	
	///Longitude of Intersection
	private double lon;
	
	///Frequency of collisions at Intersection
	private int frequency;
	
	///Risk factor of intersection
	private int risk;
	
	///Street name 1
	private String street1;
	
	///Street name 2
	private String street2;


	/**
	 * Constructor for the Intersection class
	 * @param lat - the Latitude of the intersection stored as a double 
	 * @param lon - the Longitude of the intersection stored as a double
	 * @param street1 - the Street name of one of the two roads forming the intersection
	 * @param street2 - the Street name of one of the two roads forming the intersection
	 */
	public Intersection(double lat, double lon, String street1, String street2) {
		this.lat = lat;
		this.lon = lon;
		this.frequency = 0;
		this.risk = 0;
		this.street1 = street1;
		this.street2 = street2;
	}
	

	/**
	 * getter method for the latitude of the intersection
	 * @return the latitude of the intersection
	 */
	public double getLat() {
		return lat;
	}

	/**
	 * getter method for the longitude of the intersection
	 * @return the longitude of the intersection
	 */
	public double getLon() {
		return lon;
	}
	
	/**
	 * getter method for the risk level of the intersection
	 * @return the risk level of the intersection
	 */
	public int risk() {
		return risk;
	}
	
	/**
	 * getter method for the risk level of the intersection
	 * @return the risk level of the intersection
	 */
	public int getRisk() {
		return risk;
	}

	/**
	 * setter method for the frequency of collisions of the intersection
	 * @param frequency - the frequency of collisions
	 */
	public void setFrequency(int frequency) {
		this.frequency = frequency;
		this.risk = frequency /2;
	}

	/**
	 * getter method for the frequency of collisions at the intersectiono
	 * @return the frequency of collisions at the intersection
	 */
	public int frequency() {
		return frequency;
	}

	/**
	 * getter method for one Street name forming the intersection
	 * @return One street name forming the intersection
	 */
	public String getStreet1() {
		return street1;
	}

	/**
	 * getter method for one Street name forming the intersection
	 * @return One street name forming the intersection
	 */
	public String getStreet2() {
		return street2;
	}
	

	/**
	 * Gets the distance between this intersection and another in Kilometers
	 * @return the distance in kilometers between this and another intersection
	 */
	public double getDist(Intersection p) {
		Intersection p1 = this;
		Intersection p2 = p;
		int R = 6371; // Radius of the earth in km
		double dLat = deg2rad(p2.getLat() - p1.getLat());  // deg2rad below
		double dLon = deg2rad(p2.getLon()- p1.getLon()); 
		double a = 
		Math.sin(dLat/2) * Math.sin(dLat/2) +
		Math.cos(deg2rad(p1.getLat())) * Math.cos(deg2rad(p2.getLat())) * 
		Math.sin(dLon/2) * Math.sin(dLon/2); 
		double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
		double d = R * c; // Distance in km
		return d;
	}

	/**
	 * toString implementation for a intersection
	 * @return the toString string of a intersection
	 */
	public String toString() {
		return "(" + this.lat + "," + this.lon + ") " + this.street1 + " at " + this.street2;
	}
	
	/**
	 * equals definition for comparing intersections
	 * @return the boolean representing the equivalence of two intersections
	 */
	public boolean equals(Intersection i) {
		return (this.street1.equals(i.street1) || this.street1.equals(i.street2)) && (this.street2.equals(i.street1) || this.street2.equals(i.street2));
	}
	
	/**
	 * compareTo method for the Comparable interface, compares based on frequency of collisions
	 * @return -1,0,1 depending on the frequency of collisions being compared
	 */
	public int compareTo(Intersection p) {
		return ((Integer)this.frequency).compareTo(p.frequency());
	}
	
	/**
	 * Comparison method used for comparing this and another intersection distance with respect to a third intersection
	 * @return -1,0,1 depending on the distance to the destination (third intersection)
	 */
	public int compareBy(Intersection p,Intersection dest) {
		return ((Double)this.getDist(dest)).compareTo(p.getDist(dest));
	}
	

	/**
	 * Private function used for converting degrees to radians
	 * @param deg - The degree value to be converted
	 * @return the converted degree to radians 
	 */
	private double deg2rad(double deg) {
		return deg *(Math.PI/180);
	}
	
	
	

}
